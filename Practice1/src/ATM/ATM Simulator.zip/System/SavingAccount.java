//package ATM.System;
//
//public class SavingAccount extends Accounts {
//     private double intrestRate;
//
////	public SavingAccount(double intrestRate,long accountNumber, double balance, String accountType) {
////		//super(accountNumber,balance,accountType);
////		this.intrestRate = intrestRate;
////	}
//
//	
     


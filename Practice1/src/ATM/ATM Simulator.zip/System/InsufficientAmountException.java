package ATM.System;

public class InsufficientAmountException extends Exception {
       public InsufficientAmountException(String message) {
    	   super(message);
       }
}
